using DELETE;
using Laba10;
using Lab12_3;

namespace TestProject1
{
    [TestClass]
    public class ProgramTests
    {
        private City CreateTestCity()
        {
            City city = new City("TestCity");
            Airport airport1 = new Airport("TST1");
            Airport airport2 = new Airport("TST2");
            airport1.AddAircraft(new Aircraft { Model = "Model1", ProductionYear = 1980 });
            airport1.AddAircraft(new Aircraft { Model = "Model2", ProductionYear = 1990 });
            airport2.AddAircraft(new Aircraft { Model = "Model3", ProductionYear = 2000 });
            city.AddAirport(airport1);
            city.AddAirport(airport2);
            return city;
        }

        [TestMethod]
        public void TestYearHigherThan1970()
        {
            City city = CreateTestCity();
            Program.YearHigherThan1970(city);

            var expected = city.Airports
                .SelectMany(x => x.Aircrafts)
                .Where(x => x.ProductionYear > 1970)
                .ToList();

            Assert.AreEqual(2, expected.Count);
            CollectionAssert.AllItemsAreInstancesOfType(expected, typeof(Aircraft));
        }

        [TestMethod]
        public void TestUnion()
        {
            City city1 = CreateTestCity();
            City city2 = CreateTestCity();
            city2.Airports.ElementAt(0).AddAircraft(new Aircraft { Model = "Model4", ProductionYear = 2010 });

            Program.Union(city1, city2);

            var expected = city1.Airports
                .SelectMany(x => x.Aircrafts)
                .Union(city2.Airports.SelectMany(x => x.Aircrafts))
                .ToList();

            Assert.AreEqual(4, expected.Count);
        }

        [TestMethod]
        public void TestMin()
        {
            City city = CreateTestCity();
            Program.Min(city);

            var minAircraft = city.Airports
                .SelectMany(x => x.Aircrafts)
                .Min(x => x.ProductionYear);

            Assert.AreEqual(1980, minAircraft);
        }

        [TestMethod]
        public void TestGroupBy()
        {
            City city = CreateTestCity();
            Program.GroupBy(city);

            var groups = city.Airports
                .SelectMany(x => x.Aircrafts)
                .GroupBy(x => x.Model)
                .ToList();

            Assert.AreEqual(3, groups.Count);
            Assert.IsTrue(groups.Any(g => g.Key == "Model1"));
            Assert.IsTrue(groups.Any(g => g.Key == "Model2"));
            Assert.IsTrue(groups.Any(g => g.Key == "Model3"));
        }

        [TestMethod]
        public void TestJoinAirportsAndAircrafts()
        {
            City city1 = CreateTestCity();
            City city2 = CreateTestCity();
            city2.Airports.ElementAt(0).AddAircraft(new Aircraft { Model = "Model4", ProductionYear = 2010 });

            List<City> cities = new List<City> { city1, city2 };

            Program.JoinAirportsAndAircrafts(cities);

            var joinedList = from airport in city1.Airports
                             from aircraft in airport.Aircrafts
                             select new { AirportName = airport.Name, AircraftModel = aircraft.Model };

            Assert.AreEqual(3, joinedList.Count());
        }

        [TestMethod]
        public void TestWhereTree()
        {
            var aircrafts = new MyTree<Aircraft>();
            aircrafts.Add(new Aircraft { Model = "Model1", ProductionYear = 1980 });
            aircrafts.Add(new Aircraft { Model = "Model2", ProductionYear = 1990 });
            aircrafts.Add(new Aircraft { Model = "Model3", ProductionYear = 2000 });

            Program.WhereTree(aircrafts);

            var expected = aircrafts.Where(a => a.ProductionYear > 1970).ToList();
            Assert.AreEqual(2, expected.Count);
        }

        [TestMethod]
        public void TestCountTree()
        {
            var aircrafts = new MyTree<Aircraft>();
            aircrafts.Add(new Aircraft { Model = "Model1", ProductionYear = 1980 });
            aircrafts.Add(new Aircraft { Model = "Model2", ProductionYear = 1990 });
            aircrafts.Add(new Aircraft { Model = "Model3", ProductionYear = 2000 });

            Program.ConutTree(aircrafts);

            var count = aircrafts.Count(a => a.ProductionYear > 1970);
            Assert.AreEqual(2, count);
        }

        [TestMethod]
        public void TestMinTree()
        {
            var aircrafts = new MyTree<Aircraft>();
            aircrafts.Add(new Aircraft { Model = "Model1", ProductionYear = 1980 });
            aircrafts.Add(new Aircraft { Model = "Model2", ProductionYear = 1990 });
            aircrafts.Add(new Aircraft { Model = "Model3", ProductionYear = 2000 });

            Program.MinTree(aircrafts);

            var minYear = aircrafts.Min(a => a.ProductionYear);
            Assert.AreEqual(1980, minYear);
        }

        [TestMethod]
        public void TestGroupByTree()
        {
            var aircrafts = new MyTree<Aircraft>();
            aircrafts.Add(new Aircraft { Model = "Model1", ProductionYear = 1980 });
            aircrafts.Add(new Aircraft { Model = "Model1", ProductionYear = 1990 });
            aircrafts.Add(new Aircraft { Model = "Model2", ProductionYear = 2000 });

            Program.GroupByTree(aircrafts);

            var groups = aircrafts.GroupBy(a => a.Model).ToList();
            Assert.AreEqual(2, groups.Count);
            Assert.IsTrue(groups.Any(g => g.Key == "Model1"));
            Assert.IsTrue(groups.Any(g => g.Key == "Model2"));
        }
    }
}